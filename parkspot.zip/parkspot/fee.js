// fee.js - dito kinukuwenta ang bayad
// rate = { per_hour, daily_max }, cfg = { graceMinutes, lostFee }

function computeFee(entryTime, exitTime, rate, cfg, isLost) {
  // Nawala ang ticket = flat penalty
  if (isLost) return cfg.lostFee;

  const minutes = (new Date(exitTime) - new Date(entryTime)) / 60000;

  // Sakop pa ng grace period = libre
  if (minutes <= cfg.graceMinutes) return 0;

  // Bawat buong 24 oras = daily max; ang sobra ay hourly (pa-round-up) na may daily max din
  const days = Math.floor(minutes / 1440);
  const rest = minutes - days * 1440;
  const restFee = rest > 0 ? Math.min(Math.ceil(rest / 60) * rate.per_hour, rate.daily_max) : 0;
  return days * rate.daily_max + restFee;
}

module.exports = { computeFee };