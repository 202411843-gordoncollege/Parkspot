// server.js - Express REST API + Socket.IO
const path = require('path');
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const db = require('./db');
const { computeFee } = require('./fee');

const app = express();
const server = http.createServer(app);
const io = new Server(server);

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// ---------- Helpers ----------
const getSetting = (key) => db.prepare('SELECT value FROM settings WHERE key = ?').get(key).value;

function getConfig() {
  return {
    graceMinutes: Number(getSetting('grace_minutes')),
    lostFee: Number(getSetting('lost_ticket_fee')),
    overstayHours: Number(getSetting('overstay_hours')),
  };
}

function getRates() {
  const rates = {};
  db.prepare('SELECT * FROM rates').all().forEach((r) => (rates[r.vehicle_type] = { ...r }));
  return rates;
}

const getSlots = () => db.prepare('SELECT * FROM slots ORDER BY floor, id').all();

// Plate: letters at numbers lang, para hindi malusutan ng "ABC 123" vs "ABC123"
function cleanPlate(value) {
  const plate = String(value || '').toUpperCase().replace(/[^A-Z0-9]/g, '');
  if (plate.length < 2 || plate.length > 10) throw new Error('Enter a valid plate number (2-10 letters or digits)');
  return plate;
}

const fail = (res, err, status = 400) => res.status(status).json({ error: err.message || String(err) });

// Ipadala sa lahat ng nakabukas na screen ang bagong estado ng slots
function broadcastSlots() {
  io.emit('slots-updated', getSlots());
}

// Alert kapag puno na ang floor o ang buong building
function emitFullAlerts(floor) {
  const rows = db
    .prepare("SELECT floor, SUM(status = 'available') AS free FROM slots GROUP BY floor")
    .all();
  if (rows.every((r) => r.free === 0)) {
    io.emit('alert', { type: 'building-full', message: 'The parking building is now full.' });
  } else if (rows.find((r) => r.floor === floor && r.free === 0)) {
    io.emit('alert', { type: 'floor-full', floor, message: 'Floor ' + floor + ' is now full.' });
  }
}

// Isang tao lang ang gumagamit, kaya walang login. (Naka-pass-through na lang ang mga ito.)
const anyUser = (req, res, next) => next();
const adminOnly = anyUser;

// ---------- Floors at slots ----------
function getFloors() {
  return db
    .prepare(
      `SELECT f.number, f.name, COUNT(s.id) AS total,
              COALESCE(SUM(s.status = 'available'), 0) AS available,
              COALESCE(SUM(s.status = 'occupied'), 0) AS occupied
       FROM floors f LEFT JOIN slots s ON s.floor = f.number
       GROUP BY f.number ORDER BY f.number`
    )
    .all();
}

app.get('/api/floors', anyUser, (req, res) => res.json(getFloors()));
app.get('/api/slots', anyUser, (req, res) => res.json(getSlots()));

// Pampublikong display: bilang lang ng bakante, walang plate o ibang detalye
app.get('/api/public/availability', (req, res) => {
  const floors = getFloors().map(({ number, name, total, available }) => ({ number, name, total, available }));
  res.json({ floors, available: floors.reduce((n, f) => n + f.available, 0), total: floors.reduce((n, f) => n + f.total, 0) });
});

app.post('/api/floors', adminOnly, (req, res) => {
  try {
    const slotCount = Number(req.body.slots);
    if (!Number.isInteger(slotCount) || slotCount < 1 || slotCount > 100) throw new Error('Slots must be a whole number from 1 to 100');
    const next = db.prepare('SELECT COALESCE(MAX(number), 0) + 1 AS n FROM floors').get().n;
    db.transaction(() => {
      db.prepare('INSERT INTO floors (number, name) VALUES (?, ?)').run(next, 'Floor ' + next);
      const ins = db.prepare('INSERT INTO slots (floor, slot_number) VALUES (?, ?)');
      for (let n = 1; n <= slotCount; n++) ins.run(next, `F${next}-${n}`);
    })();
    broadcastSlots();
    res.json({ floor: next, slots: slotCount });
  } catch (err) {
    fail(res, err);
  }
});

// Dagdagan ng slots ang floor na mayroon na. Ang numbering ay tuloy sa pinakahuli (F1-6, F1-7, ...)
app.post('/api/floors/:number/slots', adminOnly, (req, res) => {
  try {
    const floor = Number(req.params.number);
    const count = Number(req.body.count);
    if (!db.prepare('SELECT 1 FROM floors WHERE number = ?').get(floor)) throw new Error('Floor not found');
    if (!Number.isInteger(count) || count < 1 || count > 100) throw new Error('Slots to add must be a whole number from 1 to 100');
    const last = db
      .prepare('SELECT slot_number FROM slots WHERE floor = ?')
      .all(floor)
      .reduce((max, r) => Math.max(max, parseInt(String(r.slot_number).split('-').pop(), 10) || 0), 0);
    db.transaction(() => {
      const ins = db.prepare('INSERT INTO slots (floor, slot_number) VALUES (?, ?)');
      for (let n = 1; n <= count; n++) ins.run(floor, `F${floor}-${last + n}`);
    })();
    broadcastSlots();
    res.json({ floor, added: count, first: `F${floor}-${last + 1}`, last: `F${floor}-${last + count}` });
  } catch (err) {
    fail(res, err);
  }
});

// Burahin ang isang slot (bakante lang)
app.delete('/api/slots/:id', (req, res) => {
  try {
    const deleted = db.transaction(() => {
      const slot = db.prepare('SELECT * FROM slots WHERE id = ?').get(Number(req.params.id));
      if (!slot) throw new Error('Slot not found');
      if (slot.status === 'occupied') throw new Error(`Slot ${slot.slot_number} is occupied. Check the vehicle out first.`);
      db.prepare('DELETE FROM slots WHERE id = ?').run(slot.id);
      return slot.slot_number;
    })();
    broadcastSlots();
    res.json({ deleted });
  } catch (err) {
    fail(res, err);
  }
});

// Burahin ang buong floor (bawal kung may nakaparadang sasakyan)
app.delete('/api/floors/:number', (req, res) => {
  try {
    const number = Number(req.params.number);
    const removed = db.transaction(() => {
      if (!db.prepare('SELECT 1 FROM floors WHERE number = ?').get(number)) throw new Error('Floor not found');
      const busy = db.prepare("SELECT COUNT(*) AS n FROM slots WHERE floor = ? AND status = 'occupied'").get(number).n;
      if (busy) throw new Error(`Floor ${number} still has ${busy} parked vehicle${busy > 1 ? 's' : ''}. Check them out first.`);
      const slots = db.prepare('DELETE FROM slots WHERE floor = ?').run(number).changes;
      db.prepare('DELETE FROM floors WHERE number = ?').run(number);
      return slots;
    })();
    broadcastSlots();
    res.json({ floor: number, slotsRemoved: removed });
  } catch (err) {
    fail(res, err);
  }
});

// ---------- ENTRY (isang transaction) ----------
const enterVehicle = db.transaction((plate, vehicleType) => {
  // 1. Bawal ang parehong plate kung nakapark pa
  if (db.prepare('SELECT id FROM tickets WHERE plate = ? AND exit_time IS NULL').get(plate)) {
    throw new Error('This plate is already parked');
  }
  // 2. Maghanap ng bakanteng slot
  const slot = db.prepare("SELECT * FROM slots WHERE status = 'available' ORDER BY id LIMIT 1").get();
  if (!slot) throw new Error('Parking is full');
  // 3. Gawing occupied ang slot (may guard laban sa dobleng pagkuha)
  const taken = db.prepare("UPDATE slots SET status = 'occupied' WHERE id = ? AND status = 'available'").run(slot.id);
  if (taken.changes !== 1) throw new Error('Slot was just taken, please try again');
  // 4. Gumawa ng ticket
  const entryTime = new Date().toISOString();
  const r = db
    .prepare('INSERT INTO tickets (plate, vehicle_type, slot_id, entry_time) VALUES (?, ?, ?, ?)')
    .run(plate, vehicleType, slot.id, entryTime);
  return { ticketId: Number(r.lastInsertRowid), plate, vehicleType, slot: slot.slot_number, floor: slot.floor, entryTime };
});

app.post('/api/entry', anyUser, (req, res) => {
  try {
    const plate = cleanPlate(req.body.plate);
    const vehicleType = req.body.vehicleType;
    if (!getRates()[vehicleType]) throw new Error('Vehicle type must be car or motorcycle');
    const ticket = enterVehicle(plate, vehicleType);
    broadcastSlots();
    emitFullAlerts(ticket.floor);
    res.json(ticket);
  } catch (err) {
    fail(res, err);
  }
});

// ---------- EXIT (isang transaction: fee, payment, slot, receipt) ----------
const exitVehicle = db.transaction((plate, isLost, cashReceived) => {
  // 1. Hanapin ang ticket na bukas pa
  const t = db
    .prepare(
      `SELECT t.*, s.slot_number, s.floor FROM tickets t JOIN slots s ON s.id = t.slot_id
       WHERE t.plate = ? AND t.exit_time IS NULL`
    )
    .get(plate);
  if (!t) throw new Error('No parked vehicle with this plate number');

  // 2. Kuwentahin ang bayad
  const exitTime = new Date().toISOString();
  const fee = computeFee(t.entry_time, exitTime, getRates()[t.vehicle_type], getConfig(), isLost);
  if (cashReceived !== null && cashReceived < fee) throw new Error('Cash received is less than the fee (PHP ' + fee + ')');
  const cash = cashReceived === null ? fee : cashReceived;

  // 3. I-save ang exit time at fee sa ticket
  db.prepare('UPDATE tickets SET exit_time = ?, fee = ?, is_lost = ? WHERE id = ?')
    .run(exitTime, fee, isLost ? 1 : 0, t.id);

  // 4. I-record ang bayad (cash, simulated)
  const pay = db
    .prepare('INSERT INTO payments (ticket_id, amount, method, cash_received, change_given, paid_at) VALUES (?, ?, ?, ?, ?, ?)')
    .run(t.id, fee, 'cash', cash, cash - fee, exitTime);
  const paymentId = Number(pay.lastInsertRowid);

  // 5. Palayain ang slot
  db.prepare("UPDATE slots SET status = 'available' WHERE id = ?").run(t.slot_id);

  // 6. Gumawa at i-save ang resibo
  const receipt = {
    receiptNo: 'RC-' + String(paymentId).padStart(6, '0'),
    plate: t.plate,
    vehicleType: t.vehicle_type,
    slot: t.slot_number,
    floor: t.floor,
    entryTime: t.entry_time,
    exitTime,
    minutes: Math.max(1, Math.round((new Date(exitTime) - new Date(t.entry_time)) / 60000)),
    fee,
    lostTicket: !!isLost,
    cashReceived: cash,
    change: cash - fee,
  };
  db.prepare('INSERT INTO receipts (receipt_no, ticket_id, payment_id, issued_at, data) VALUES (?, ?, ?, ?, ?)')
    .run(receipt.receiptNo, t.id, paymentId, exitTime, JSON.stringify(receipt));
  return receipt;
});

app.post('/api/exit', anyUser, (req, res) => {
  try {
    const plate = cleanPlate(req.body.plate);
    let cash = null;
    if (req.body.cashReceived !== undefined && req.body.cashReceived !== null && req.body.cashReceived !== '') {
      cash = Number(req.body.cashReceived);
      if (!Number.isFinite(cash) || cash < 0) throw new Error('Cash received must be a valid amount');
    }
    const receipt = exitVehicle(plate, req.body.lost === true, cash);
    broadcastSlots();
    res.json(receipt);
  } catch (err) {
    fail(res, err);
  }
});

// ---------- Hanapin ang sasakyan, payments, receipts ----------
app.get('/api/find/:plate', anyUser, (req, res) => {
  try {
    const row = db
      .prepare(
        `SELECT t.plate, t.vehicle_type, s.slot_number, s.floor, t.entry_time
         FROM tickets t JOIN slots s ON s.id = t.slot_id
         WHERE t.plate = ? AND t.exit_time IS NULL`
      )
      .get(cleanPlate(req.params.plate));
    if (!row) return res.status(404).json({ error: 'No parked vehicle with this plate number' });
    res.json(row);
  } catch (err) {
    fail(res, err);
  }
});

// Sino ang nakapark sa bawat slot (para sa hover sa grid). Naka-login lang ang may access,
// kaya hindi lumalabas ang plate sa pampublikong display.
app.get('/api/occupants', anyUser, (req, res) => {
  res.json(
    db
      .prepare('SELECT slot_id, plate, vehicle_type, entry_time FROM tickets WHERE exit_time IS NULL')
      .all()
  );
});

app.get('/api/payments', adminOnly, (req, res) => {
  const limit = Math.min(Number(req.query.limit) || 25, 200);
  res.json(
    db
      .prepare(
        `SELECT p.id, p.amount, p.method, p.paid_at, t.plate, t.vehicle_type, r.receipt_no
         FROM payments p
         JOIN tickets t ON t.id = p.ticket_id
         LEFT JOIN receipts r ON r.payment_id = p.id
         ORDER BY p.id DESC LIMIT ?`
      )
      .all(limit)
  );
});

app.get('/api/receipts/:no', anyUser, (req, res) => {
  const row = db.prepare('SELECT data FROM receipts WHERE receipt_no = ?').get(req.params.no.toUpperCase());
  if (!row) return res.status(404).json({ error: 'Receipt not found' });
  res.json(JSON.parse(row.data));
});

// ---------- Fee rates at settings ----------
app.get('/api/rates', anyUser, (req, res) => {
  res.json({ rates: getRates(), ...getConfig() });
});

app.put('/api/rates', adminOnly, (req, res) => {
  try {
    const whole = (v, label, min = 0) => {
      const n = Number(v);
      if (!Number.isInteger(n) || n < min) throw new Error(label + ' must be a whole number' + (min ? ' of at least ' + min : ''));
      return n;
    };
    db.transaction(() => {
      for (const type of ['car', 'motorcycle']) {
        const r = (req.body.rates || {})[type];
        if (!r) continue;
        const perHour = whole(r.per_hour, type + ' hourly rate');
        const dailyMax = whole(r.daily_max, type + ' daily maximum');
        if (dailyMax < perHour) throw new Error('Daily maximum for ' + type + ' cannot be lower than the hourly rate');
        db.prepare('UPDATE rates SET per_hour = ?, daily_max = ? WHERE vehicle_type = ?').run(perHour, dailyMax, type);
      }
      const set = db.prepare('UPDATE settings SET value = ? WHERE key = ?');
      if (req.body.graceMinutes !== undefined) set.run(String(whole(req.body.graceMinutes, 'Grace period')), 'grace_minutes');
      if (req.body.lostFee !== undefined) set.run(String(whole(req.body.lostFee, 'Lost ticket fee')), 'lost_ticket_fee');
      if (req.body.overstayHours !== undefined) set.run(String(whole(req.body.overstayHours, 'Overstay hours', 1)), 'overstay_hours');
    })();
    res.json({ rates: getRates(), ...getConfig() });
  } catch (err) {
    fail(res, err);
  }
});

// ---------- Reports (admin) ----------
// Kita ngayong araw (para sa dashboard)
app.get('/api/reports/today', anyUser, (req, res) => {
  res.json(
    db
      .prepare(
        `SELECT COUNT(*) AS vehicles, COALESCE(SUM(amount), 0) AS revenue FROM payments
         WHERE date(paid_at, 'localtime') = date('now', 'localtime')`
      )
      .get()
  );
});

// Daily o monthly revenue: /api/reports/revenue?period=daily|monthly
app.get('/api/reports/revenue', adminOnly, (req, res) => {
  const monthly = req.query.period === 'monthly';
  const fmt = monthly ? "strftime('%Y-%m', paid_at, 'localtime')" : "date(paid_at, 'localtime')";
  res.json(
    db
      .prepare(
        `SELECT ${fmt} AS period, COUNT(*) AS vehicles, SUM(amount) AS revenue
         FROM payments GROUP BY period ORDER BY period DESC LIMIT ?`
      )
      .all(monthly ? 12 : 31)
  );
});

// Occupancy rate per floor (ngayon)
app.get('/api/reports/occupancy', adminOnly, (req, res) => {
  res.json(
    getFloors().map((f) => ({ ...f, rate: f.total ? Math.round((f.occupied / f.total) * 100) : 0 }))
  );
});

// Peak hours: ilan ang pumasok bawat oras ng araw
app.get('/api/reports/peak-hours', adminOnly, (req, res) => {
  const rows = db
    .prepare("SELECT CAST(strftime('%H', entry_time, 'localtime') AS INTEGER) AS hour, COUNT(*) AS entries FROM tickets GROUP BY hour")
    .all();
  const byHour = Object.fromEntries(rows.map((r) => [r.hour, r.entries]));
  res.json(Array.from({ length: 24 }, (_, hour) => ({ hour, entries: byHour[hour] || 0 })));
});

// Average parking duration (minuto) ng mga nakaalis na
app.get('/api/reports/avg-duration', adminOnly, (req, res) => {
  const minutes = '(julianday(exit_time) - julianday(entry_time)) * 1440';
  res.json({
    overall: db
      .prepare(`SELECT COUNT(*) AS vehicles, ROUND(AVG(${minutes}), 1) AS avg_minutes FROM tickets WHERE exit_time IS NOT NULL`)
      .get(),
    byType: db
      .prepare(
        `SELECT vehicle_type, COUNT(*) AS vehicles, ROUND(AVG(${minutes}), 1) AS avg_minutes
         FROM tickets WHERE exit_time IS NOT NULL GROUP BY vehicle_type`
      )
      .all(),
  });
});

// Mga sasakyang matagal nang nakapark: /api/reports/overstay?hours=24
app.get('/api/reports/overstay', adminOnly, (req, res) => {
  const hours = Number(req.query.hours) || getConfig().overstayHours;
  const rows = db
    .prepare(
      `SELECT t.plate, t.vehicle_type, t.entry_time, s.slot_number, s.floor
       FROM tickets t JOIN slots s ON s.id = t.slot_id WHERE t.exit_time IS NULL ORDER BY t.entry_time`
    )
    .all()
    .map((r) => ({ ...r, hours_parked: Math.round(((Date.now() - new Date(r.entry_time)) / 3600000) * 10) / 10 }))
    .filter((r) => r.hours_parked >= hours);
  res.json({ hours, vehicles: rows });
});

// ---------- Socket.IO ----------
// Pampubliko ang slot status (walang plate), kaya puwedeng makinig kahit ang display ng mga driver
io.on('connection', (socket) => {
  socket.emit('slots-updated', getSlots());
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => console.log('ParkSpot running on port ' + PORT));
