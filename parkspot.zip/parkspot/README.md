# ParkSpot - Parking Slot Management System

## Run
    npm install
    npm start
Open http://localhost:3000  (needs Node.js 22.13 or newer)

Walang login: isang tao lang ang gumagamit.

## Pages
- /              - Parking (check in, check out, find, live slots, Edit floors), Reports, Rates
- /display.html  - public availability display (bilang lang ng bakante, walang plate)

## Edit floors
Pindutin ang "Edit" sa tabi ng floor para magdagdag ng slots, magbura ng bakanteng slot (x),
o magbura ng floor. Bawal ang pagbura kung may nakaparadang sasakyan. "+ Add floor" para sa bagong floor.

## API
- GET /api/floors, GET /api/slots, POST /api/floors, POST /api/floors/:n/slots,
  DELETE /api/floors/:n, DELETE /api/slots/:id, GET /api/public/availability, GET /api/occupants
- POST /api/entry, POST /api/exit, GET /api/find/:plate
- GET/PUT /api/rates, GET /api/payments, GET /api/receipts/:no
- GET /api/reports/{today, revenue?period=daily|monthly, occupancy, peak-hours, avg-duration, overstay?hours=}