// pdf.js - PDF maker
//   1) SimplePdf - basic writer
//   2) dailyReportPdf - report content

const PAGE_W = 595; // A4
const PAGE_H = 842;

class SimplePdf {
  constructor() {
    this.pages = [[]]; // Commands per page
  }

  newPage() {
    this.pages.push([]);
  }

  // Clean text for PDF
  clean(s) {
    return String(s)
      .replace(/[\u00a0\u2000-\u200b\u202f]/g, ' ')
      .replace(/[^\x20-\x7e]/g, '?')
      .replace(/([\\()])/g, '\\$1');
  }

  // Add text at x, y
  text(x, y, s, size = 10, bold = false, page = this.pages.length - 1) {
    this.pages[page].push(`BT /${bold ? 'F2' : 'F1'} ${size} Tf ${x} ${y} Td (${this.clean(s)}) Tj ET`);
  }

  line(x1, y1, x2, y2, page = this.pages.length - 1) {
    this.pages[page].push(`0.5 w ${x1} ${y1} m ${x2} ${y2} l S`);
  }

  // Build PDF file
  toBuffer() {
    const objects = [];
    objects.push('<< /Type /Catalog /Pages 2 0 R >>');
    const kids = this.pages.map((_, i) => `${5 + i * 2} 0 R`).join(' ');
    objects.push(`<< /Type /Pages /Kids [${kids}] /Count ${this.pages.length} >>`);
    objects.push('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica /Encoding /WinAnsiEncoding >>');
    objects.push('<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold /Encoding /WinAnsiEncoding >>');
    this.pages.forEach((ops, i) => {
      const content = ops.join('\n');
      objects.push(
        `<< /Type /Page /Parent 2 0 R /MediaBox [0 0 ${PAGE_W} ${PAGE_H}] ` +
        `/Resources << /Font << /F1 3 0 R /F2 4 0 R >> >> /Contents ${6 + i * 2} 0 R >>`
      );
      objects.push(`<< /Length ${content.length} >>\nstream\n${content}\nendstream`);
    });

    let out = '%PDF-1.4\n';
    const offsets = [];
    objects.forEach((body, i) => {
      offsets.push(out.length);
      out += `${i + 1} 0 obj\n${body}\nendobj\n`;
    });
    const xref = out.length;
    out += `xref\n0 ${objects.length + 1}\n0000000000 65535 f \n`;
    offsets.forEach((o) => { out += String(o).padStart(10, '0') + ' 00000 n \n'; });
    out += `trailer\n<< /Size ${objects.length + 1} /Root 1 0 R >>\nstartxref\n${xref}\n%%EOF`;
    return Buffer.from(out, 'latin1');
  }
}

// ---------- Daily report ----------
const peso = (n) => 'PHP ' + Number(n || 0).toLocaleString('en-US');
const clock = (iso, withDate) =>
  new Date(iso).toLocaleString('en-US',
    withDate ? { month: 'short', day: 'numeric', hour: 'numeric', minute: '2-digit' }
             : { hour: 'numeric', minute: '2-digit' });

function parkedText(from, to) {
  const m = Math.max(1, Math.round((new Date(to) - new Date(from)) / 60000));
  const h = Math.floor(m / 60);
  return h ? `${h} h ${m % 60} min` : `${m} min`;
}

// date, rows, entered count
function dailyReportPdf(date, rows, entered) {
  const [yr, mo, dy] = date.split('-').map(Number);
  const longDate = new Date(yr, mo - 1, dy).toLocaleDateString('en-US',
    { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  const total = rows.reduce((sum, r) => sum + (Number(r.fee) || 0), 0);
  const lost = rows.filter((r) => r.is_lost).length;

  const pdf = new SimplePdf();
  pdf.text(40, 790, 'ParkSpot Daily Report', 22, true);
  pdf.text(40, 768, longDate, 12);
  pdf.line(40, 756, 555, 756);

  // Day summary
  const summary = [
    ['Total revenue', peso(total), true],
    ['Vehicles checked out (paid)', String(rows.length)],
    ['Vehicles checked in', String(entered)],
    ['Lost tickets', String(lost)],
  ];
  let y = 734;
  summary.forEach(([label, value, bold]) => {
    pdf.text(40, y, label, 11);
    pdf.text(230, y, value, 11, !!bold);
    y -= 18;
  });

  // Vehicle table
  const cols = [['Receipt', 40], ['Plate', 100], ['Vehicle', 165], ['Time in', 230],
                ['Time out', 315], ['Parked', 400], ['Fee', 470]];
  const header = () => {
    cols.forEach(([label, x]) => pdf.text(x, y, label, 9, true));
    pdf.line(40, y - 4, 555, y - 4);
    y -= 18;
  };
  y -= 14;
  pdf.text(40, y, 'Vehicles checked out', 13, true);
  y -= 22;
  header();

  if (!rows.length) pdf.text(40, y, 'No vehicles checked out on this day.', 10);
  rows.forEach((r) => {
    if (y < 70) { pdf.newPage(); y = 790; header(); }
    const enteredToday = new Date(r.entry_time).toLocaleDateString('en-CA') === date;
    const cells = [
      r.receipt_no || '-',
      r.plate,
      r.vehicle_type === 'car' ? 'Car' : 'Motorcycle',
      clock(r.entry_time, !enteredToday),
      clock(r.exit_time, false),
      parkedText(r.entry_time, r.exit_time),
      peso(r.fee) + (r.is_lost ? ' (lost)' : ''),
    ];
    cells.forEach((text, i) => pdf.text(cols[i][1], y, text, 9));
    y -= 16;
  });

  if (rows.length) {
    if (y < 70) { pdf.newPage(); y = 790; }
    pdf.line(40, y + 8, 555, y + 8);
    pdf.text(400, y - 6, 'Total', 10, true);
    pdf.text(470, y - 6, peso(total), 10, true);
  }

  // Page footers
  const count = pdf.pages.length;
  for (let i = 0; i < count; i++) {
    pdf.text(40, 30, 'Generated ' + new Date().toLocaleString('en-US'), 8, false, i);
    pdf.text(500, 30, `Page ${i + 1} of ${count}`, 8, false, i);
  }
  return pdf.toBuffer();
}

module.exports = { dailyReportPdf };
