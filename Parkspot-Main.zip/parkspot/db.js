// db.js - database and tables
// Built-in Node SQLite
const { DatabaseSync } = require('node:sqlite');

const db = new DatabaseSync(process.env.DB_FILE || 'parkspot.db');

db.exec(`
  CREATE TABLE IF NOT EXISTS floors (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    number INTEGER UNIQUE NOT NULL,
    name TEXT
  );

  CREATE TABLE IF NOT EXISTS slots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    floor INTEGER,
    slot_number TEXT,
    status TEXT DEFAULT 'available'
  );

  CREATE TABLE IF NOT EXISTS tickets (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    plate TEXT,
    vehicle_type TEXT,
    slot_id INTEGER,
    entry_time TEXT,
    exit_time TEXT,
    fee INTEGER,
    is_lost INTEGER DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS rates (
    vehicle_type TEXT PRIMARY KEY,
    per_hour INTEGER NOT NULL,
    daily_max INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS payments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    ticket_id INTEGER NOT NULL,
    amount INTEGER NOT NULL,
    method TEXT NOT NULL DEFAULT 'cash',
    cash_received INTEGER,
    change_given INTEGER,
    paid_at TEXT NOT NULL,
    attendant_id INTEGER
  );

  CREATE TABLE IF NOT EXISTS receipts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    receipt_no TEXT UNIQUE NOT NULL,
    ticket_id INTEGER NOT NULL,
    payment_id INTEGER NOT NULL,
    issued_at TEXT NOT NULL,
    data TEXT NOT NULL
  );
`);

// Add missing columns
function addColumn(table, column, def) {
  const cols = db.prepare(`PRAGMA table_info(${table})`).all().map((c) => c.name);
  if (!cols.includes(column)) db.exec(`ALTER TABLE ${table} ADD COLUMN ${column} ${def}`);
}
addColumn('tickets', 'attendant_in', 'INTEGER');
addColumn('tickets', 'attendant_out', 'INTEGER');

// Fill floors from slots
db.prepare(
  `INSERT OR IGNORE INTO floors (number, name)
   SELECT DISTINCT floor, 'Floor ' || floor FROM slots`
).run();

db.prepare('INSERT OR IGNORE INTO rates (vehicle_type, per_hour, daily_max) VALUES (?, ?, ?)').run('car', 40, 300);
db.prepare('INSERT OR IGNORE INTO rates (vehicle_type, per_hour, daily_max) VALUES (?, ?, ?)').run('motorcycle', 20, 150);

const defaults = { grace_minutes: '15', lost_ticket_fee: '500', overstay_hours: '24' };
for (const [k, v] of Object.entries(defaults)) {
  db.prepare('INSERT OR IGNORE INTO settings (key, value) VALUES (?, ?)').run(k, v);
}

// Transaction with write lock
db.transaction = function (fn) {
  return function (...args) {
    db.exec('BEGIN IMMEDIATE');
    try {
      const result = fn(...args);
      db.exec('COMMIT');
      return result;
    } catch (err) {
      db.exec('ROLLBACK');
      throw err;
    }
  };
};

module.exports = db;