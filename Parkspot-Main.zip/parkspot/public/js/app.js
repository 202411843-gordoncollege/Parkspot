// app.js - main page logic
connectLive(renderLive);

// ---------- Tabs ----------
const loaded = {};
document.querySelectorAll('.nav-btn').forEach((btn) =>
  btn.addEventListener('click', () => {
    document.querySelectorAll('.nav-btn').forEach((b) => b.classList.toggle('active', b === btn));
    document.querySelectorAll('.tab-panel').forEach((p) => (p.hidden = p.id !== 'tab-' + btn.dataset.tab));
    if (btn.dataset.tab === 'reports') loadReports();
    if (btn.dataset.tab === 'settings' && !loaded.settings) loadSettings();
  })
);

const note = (msg) => toast(msg, 'ok');
const problem = (err) => toast(err.message, 'warn');

// ---------- Check in / out / find ----------
function submitSafely(formId, handler, failTitle) {
  $(formId).addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = e.submitter;
    btn.disabled = true;
    try {
      await handler();
    } catch (err) {
      showResult('err', failTitle, [['Reason', err.message]]);
    } finally {
      btn.disabled = false;
    }
  });
}

submitSafely('entryForm', async () => {
  const t = await api('/api/entry', { method: 'POST', body: { plate: $('entryPlate').value, vehicleType: $('entryType').value } });
  showResult('ok', 'Vehicle checked in', [
    ['Ticket', '#' + t.ticketId],
    ['Plate', t.plate],
    ['Slot', t.slot + ' (Floor ' + t.floor + ')'],
    ['Entry time', fmtTime(t.entryTime)],
  ]);
  $('entryPlate').value = '';
  $('entryPlate').focus();
}, 'Check-in failed');

submitSafely('exitForm', async () => {
  const r = await api('/api/exit', {
    method: 'POST',
    body: { plate: $('exitPlate').value, lost: $('lostTicket').checked, cashReceived: $('cashReceived').value },
  });
  showResult('ok', 'Receipt ' + r.receiptNo, [
    ['Plate', r.plate],
    ['Vehicle', typeName(r.vehicleType)],
    ['Slot', r.slot + ' (Floor ' + r.floor + ')'],
    ['Time parked', fmtMinutes(r.minutes)],
    ['Ticket', r.lostTicket ? 'Lost' : 'Presented'],
    ['Cash received', peso(r.cashReceived)],
    ['Change', peso(r.change)],
    ['Fee due', peso(r.fee), 'fee'],
  ]);
  $('exitPlate').value = '';
  $('cashReceived').value = '';
  $('lostTicket').checked = false;
  $('exitPlate').focus();
}, 'Check-out failed');

submitSafely('findForm', async () => {
  const f = await api('/api/find/' + encodeURIComponent($('findPlate').value));
  showResult('ok', 'Vehicle found', [
    ['Plate', f.plate],
    ['Slot', f.slot_number + ' (Floor ' + f.floor + ')'],
    ['Vehicle', typeName(f.vehicle_type)],
    ['Parked since', fmtTime(f.entry_time)],
  ]);
}, 'Not found');

// ---------- Click slot to check out ----------
function pickSlot(bay) {
  if (!bay || !bay.dataset.plate) return;
  $('exitPlate').value = bay.dataset.plate;
  document.querySelectorAll('.bay.picked').forEach((b) => b.classList.remove('picked'));
  bay.classList.add('picked');
  $('exitForm').closest('.panel').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  $('cashReceived').focus({ preventScroll: true });
  note(bay.dataset.plate + ' ready for check out');
}
$('floors').addEventListener('click', (e) => {
  if (e.target.closest('.bay-del')) return;
  pickSlot(e.target.closest('.bay.occupied'));
});
$('floors').addEventListener('keydown', (e) => {
  if ((e.key === 'Enter' || e.key === ' ') && e.target.matches('.bay.occupied')) {
    e.preventDefault();
    pickSlot(e.target);
  }
});
$('exitPlate').addEventListener('input', () => decorateOccupants());

// ---------- Edit floors and slots ----------
const editing = new Set();
const addValues = {};

liveOptions = {
  editing,
  values: addValues,
  onToggle(floor) {
    editing.has(floor) ? editing.delete(floor) : editing.add(floor);
    renderLive(currentSlots);
  },
  async onAdd(floor, count) {
    try {
      const r = await api('/api/floors/' + floor + '/slots', { method: 'POST', body: { count } });
      note(r.added + (r.added > 1 ? ' slots' : ' slot') + ' added to Floor ' + floor + ' (' + r.first + (r.added > 1 ? ' to ' + r.last : '') + ')');
    } catch (err) { problem(err); }
  },
  async onDeleteSlot(slot) {
    if (!confirm('Delete slot ' + slot.slot_number + '?')) return;
    try {
      const r = await api('/api/slots/' + slot.id, { method: 'DELETE' });
      note('Slot ' + r.deleted + ' deleted');
    } catch (err) { problem(err); }
  },
  async onDeleteFloor(floor, slotCount) {
    if (!confirm('Delete Floor ' + floor + (slotCount ? ' and its ' + slotCount + ' slots' : '') + '?')) return;
    try {
      await api('/api/floors/' + floor, { method: 'DELETE' });
      editing.delete(floor);
      note('Floor ' + floor + ' deleted');
    } catch (err) { problem(err); }
  },
};

$('addFloor').addEventListener('click', async () => {
  try {
    const f = await api('/api/floors', { method: 'POST', body: { slots: $('newFloorSlots').value } });
    note('Floor ' + f.floor + ' added with ' + f.slots + ' slots');
    editing.add(f.floor); // Open edit mode
    renderLive(currentSlots);
  } catch (err) { problem(err); }
});

// ---------- Reports ----------
async function loadRevenue() {
  const rows = await api('/api/reports/revenue?period=' + $('revPeriod').value);
  $('revenue').replaceChildren(
    makeTable(['Period', 'Vehicles', 'Revenue'], rows.map((r) => [r.period, r.vehicles, peso(r.revenue)]), 'No payments recorded yet.')
  );
}

async function loadOccupancy() {
  const rows = await api('/api/reports/occupancy');
  const box = $('occupancy');
  box.replaceChildren();
  if (!rows.length) box.append(el('p', 'empty', 'No floors yet.'));
  rows.forEach((f) => {
    const row = el('div', 'occ-row');
    row.append(el('span', 'occ-name', 'Floor ' + f.number));
    const meter = el('div', 'meter');
    const fill = el('div', 'meter-fill');
    fill.style.width = f.rate + '%';
    meter.append(fill);
    row.append(meter, el('span', 'occ-pct', f.rate + '% (' + f.occupied + '/' + f.total + ')'));
    box.append(row);
  });
}

async function loadPeak() {
  const rows = await api('/api/reports/peak-hours');
  const max = Math.max(1, ...rows.map((r) => r.entries));
  const chart = el('div', 'bars');
  rows.forEach((r) => {
    const col = el('div', 'bar-col');
    col.title = r.hour + ':00 – ' + r.entries + ' entries';
    const bar = el('div', 'bar');
    bar.style.height = (r.entries / max) * 100 + '%';
    col.append(el('span', 'bar-val', r.entries ? String(r.entries) : ''), bar, el('span', 'bar-label', String(r.hour)));
    chart.append(col);
  });
  $('peak').replaceChildren(chart);
  const busiest = rows.reduce((a, b) => (b.entries > a.entries ? b : a), rows[0]);
  if (busiest.entries) $('peak').append(el('p', 'muted small', 'Busiest hour: ' + busiest.hour + ':00 (' + busiest.entries + ' entries).'));
}

async function loadDuration() {
  const d = await api('/api/reports/avg-duration');
  const rows = [['All vehicles', d.overall.vehicles, d.overall.vehicles ? fmtMinutes(d.overall.avg_minutes) : '–']];
  d.byType.forEach((t) => rows.push([typeName(t.vehicle_type), t.vehicles, fmtMinutes(t.avg_minutes)]));
  $('duration').replaceChildren(makeTable(['Group', 'Completed stays', 'Average'], rows));
}

async function loadOverstay() {
  const hours = Number($('overHours').value) || 24;
  const d = await api('/api/reports/overstay?hours=' + hours);
  $('overstay').replaceChildren(
    makeTable(['Plate', 'Slot', 'Parked', 'Since'],
      d.vehicles.map((v) => [v.plate, v.slot_number, fmtMinutes(v.hours_parked * 60), fmtTime(v.entry_time)]),
      'No vehicle has been parked for over ' + d.hours + ' hours.')
  );
}

async function loadPayments() {
  const rows = await api('/api/payments?limit=25');
  $('payments').replaceChildren(
    makeTable(['Receipt', 'Plate', 'Vehicle', 'Checked in', 'Paid at', 'Amount'],
      rows.map((p) => [p.receipt_no, p.plate, typeName(p.vehicle_type), fmtTime(p.entry_time), fmtTime(p.paid_at), peso(p.amount)]),
      'No payments recorded yet.')
  );
}

function loadReports() {
  Promise.all([loadRevenue(), loadOccupancy(), loadPeak(), loadDuration(), loadOverstay(), loadPayments()]).catch(problem);
}
$('revPeriod').addEventListener('change', () => loadRevenue().catch(problem));
$('overHours').addEventListener('change', () => loadOverstay().catch(problem));
$('refresh').addEventListener('click', loadReports);

// ---------- Download PDF ----------
$('pdfDate').value = new Date().toLocaleDateString('en-CA'); // Default: today
$('pdfDate').max = $('pdfDate').value;                        // No future dates
$('downloadPdf').addEventListener('click', async () => {
  const date = $('pdfDate').value;
  if (!date) return problem(new Error('Choose a date first'));
  try {
    const res = await fetch('/api/reports/daily.pdf?date=' + date);
    if (!res.ok) {
      const data = await res.json().catch(() => ({}));
      throw new Error(data.error || 'Could not create the PDF');
    }
    const link = document.createElement('a');
    link.href = URL.createObjectURL(await res.blob());
    link.download = 'parkspot-report-' + date + '.pdf';
    link.click();
    URL.revokeObjectURL(link.href);
    note('PDF report for ' + date + ' downloaded');
  } catch (err) { problem(err); }
});

// ---------- Rates ----------
async function loadSettings() {
  const s = await api('/api/rates');
  $('carHour').value = s.rates.car.per_hour;
  $('carMax').value = s.rates.car.daily_max;
  $('motoHour').value = s.rates.motorcycle.per_hour;
  $('motoMax').value = s.rates.motorcycle.daily_max;
  $('grace').value = s.graceMinutes;
  $('lostFee').value = s.lostFee;
  $('overDefault').value = s.overstayHours;
  $('overHours').value = s.overstayHours;
  loaded.settings = true;
}
loadSettings().catch(problem); // Default overstay hours

$('ratesForm').addEventListener('submit', async (e) => {
  e.preventDefault();
  try {
    await api('/api/rates', {
      method: 'PUT',
      body: {
        rates: {
          car: { per_hour: $('carHour').value, daily_max: $('carMax').value },
          motorcycle: { per_hour: $('motoHour').value, daily_max: $('motoMax').value },
        },
        graceMinutes: $('grace').value,
        lostFee: $('lostFee').value,
        overstayHours: $('overDefault').value,
      },
    });
    $('overHours').value = $('overDefault').value; // Sync overstay threshold
    loadOverstay().catch(problem);
    note('Rates saved. They apply to check-outs from now on.');
  } catch (err) { problem(err); }
});
