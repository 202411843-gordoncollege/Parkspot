// common.js - shared helpers
const $ = (id) => document.getElementById(id);

function el(tag, className, text) {
  const node = document.createElement(tag);
  if (className) node.className = className;
  if (text !== undefined) node.textContent = text;
  return node;
}

// ---------- API ----------
async function api(url, { method = 'GET', body } = {}) {
  const res = await fetch(url, {
    method,
    headers: { 'Content-Type': 'application/json' },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error || 'Request failed');
  return data;
}

// ---------- Live updates ----------
function connectLive(onSlots) {
  const socket = io();
  const live = $('live');
  const liveText = $('liveText');
  socket.on('connect', () => { live.className = 'live on'; liveText.textContent = 'Live'; });
  socket.on('disconnect', () => { live.className = 'live off'; liveText.textContent = 'Disconnected, retrying…'; });
  socket.on('slots-updated', onSlots);
  socket.on('alert', (a) => toast(a.message, 'warn'));
  return socket;
}

function toast(message, kind) {
  const box = $('toasts');
  if (!box) return;
  const t = el('div', 'toast ' + (kind || ''), message);
  t.title = 'Click to dismiss';
  t.addEventListener('click', () => t.remove());
  box.append(t);
  while (box.children.length > 3) box.firstChild.remove(); // Max three toasts
  setTimeout(() => t.remove(), 4500);
}

// ---------- Slot grid and counters ----------
function groupByFloor(slots) {
  const floors = {};
  slots.forEach((s) => (floors[s.floor] = floors[s.floor] || []).push(s));
  return floors;
}

// Draw floors and slots
function drawSlots(container, slots, floors, opts = {}) {
  container.replaceChildren();
  const byFloor = groupByFloor(slots);
  const list = floors || Object.keys(byFloor).map((n) => ({ number: Number(n) }));
  if (!list.length) { container.append(el('p', 'empty', 'No floors yet. Use “Add floor” to create one.')); return; }

  list.forEach(({ number }) => {
    const items = byFloor[number] || [];
    const free = items.filter((s) => s.status === 'available').length;
    const editing = !!(opts.editing && opts.editing.has(number));

    const section = el('div', 'floor');
    const head = el('div', 'floor-head');
    head.append(el('h3', 'floor-title', 'Floor ' + number));
    const right = el('div', 'floor-right');
    right.append(el('span', 'badge' + (items.length && free === 0 ? ' full' : ''),
      !items.length ? 'No slots' : free === 0 ? 'Full' : free + ' of ' + items.length + ' available'));
    if (opts.onToggle) {
      const edit = el('button', 'edit-btn' + (editing ? ' on' : ''), editing ? 'Done' : 'Edit');
      edit.type = 'button';
      edit.addEventListener('click', () => opts.onToggle(number));
      right.append(edit);
    }
    head.append(right);
    section.append(head);

    if (editing) {
      const tools = el('div', 'floor-tools');
      const input = el('input', 'mini');
      input.type = 'number'; input.min = 1; input.max = 100; input.step = 1;
      input.value = (opts.values && opts.values[number]) || 1;
      input.setAttribute('aria-label', 'Number of slots to add to floor ' + number);
      input.addEventListener('input', () => { if (opts.values) opts.values[number] = input.value; });
      const add = el('button', 'btn btn-light btn-sm', 'Add slots');
      add.type = 'button';
      add.addEventListener('click', () => opts.onAdd(number, input.value));
      const del = el('button', 'btn btn-danger btn-sm', 'Delete floor');
      del.type = 'button';
      del.addEventListener('click', () => opts.onDeleteFloor(number, items.length));
      tools.append(input, add, del);
      section.append(tools);
    }

    const bays = el('div', 'bays');
    items.forEach((s) => {
      const bay = el('div', 'bay ' + s.status);
      bay.dataset.slotId = s.id;
      bay.append(el('span', 'bay-num', s.slot_number));
      bay.append(el('span', 'bay-state', s.status === 'available' ? 'Available' : 'Occupied'));
      if (editing && s.status === 'available') {
        const x = el('button', 'bay-del', '×');
        x.type = 'button';
        x.title = 'Delete slot ' + s.slot_number;
        x.setAttribute('aria-label', 'Delete slot ' + s.slot_number);
        x.addEventListener('click', () => opts.onDeleteSlot(s));
        bay.append(x);
      }
      bays.append(bay);
    });
    if (!items.length) bays.append(el('p', 'bays-empty', 'This floor has no slots. Add some with the box above.'));
    section.append(bays);
    container.append(section);
  });
}

function drawSummary(slots) {
  const total = slots.length;
  const taken = slots.filter((s) => s.status === 'occupied').length;
  const pct = total ? Math.round((taken / total) * 100) : 0;
  $('statFree').textContent = total - taken;
  $('statTaken').textContent = taken;
  $('meterFill').style.width = pct + '%';
  $('statPct').textContent = pct + '% of ' + total + ' slots in use';
}

// Full floor banner
function drawBanner(slots) {
  const banner = $('banner');
  if (!banner) return;
  const floors = groupByFloor(slots);
  const full = Object.keys(floors).filter((f) => floors[f].every((s) => s.status === 'occupied'));
  if (slots.length && full.length === Object.keys(floors).length) {
    banner.textContent = 'Parking is FULL. No available slots in the building.';
    banner.hidden = false;
  } else if (full.length) {
    banner.textContent = 'Full: ' + full.map((f) => 'Floor ' + f).join(', ') + '. Direct drivers to other floors.';
    banner.hidden = false;
  } else {
    banner.hidden = true;
  }
}

// Show plate on slots
async function decorateOccupants() {
  try {
    const list = await api('/api/occupants');
    const bySlot = {};
    list.forEach((o) => (bySlot[o.slot_id] = o));
    document.querySelectorAll('.bay.occupied').forEach((bay) => {
      const o = bySlot[bay.dataset.slotId];
      if (!o) return;
      bay.dataset.tip = o.plate + ' · ' + typeName(o.vehicle_type) + ' · since ' +
        new Date(o.entry_time).toLocaleTimeString('en-PH', { hour: 'numeric', minute: '2-digit' });
      bay.dataset.plate = o.plate;
      bay.tabIndex = 0;
      bay.setAttribute('aria-label', 'Occupied by ' + o.plate + '. Press to fill check out.');
      const typed = ($('exitPlate') ? $('exitPlate').value : '').toUpperCase().replace(/[^A-Z0-9]/g, '');
      bay.classList.toggle('picked', !!typed && typed === o.plate);
    });
  } catch { /* tooltip is optional */ }
}

// Edit mode options
let liveOptions = {};
let currentSlots = [];
let renderSeq = 0;

async function renderLive(slots) {
  currentSlots = slots;
  const seq = ++renderSeq;
  drawSummary(slots);
  drawBanner(slots);
  let floors = null;
  try { floors = await api('/api/floors'); } catch { /* fall back to slots */ }
  if (seq !== renderSeq) return; // Newer update exists
  drawSlots($('floors'), slots, floors, liveOptions);
  decorateOccupants();
}

// ---------- Small helpers ----------
function showResult(kind, title, rows) {
  const box = $('result');
  box.hidden = false;
  box.className = 'result ' + kind;
  box.replaceChildren(el('h3', '', title));
  if (rows && rows.length) {
    const dl = el('dl');
    rows.forEach(([label, value, cls]) => {
      dl.append(el('dt', '', label));
      dl.append(el('dd', cls || '', value));
    });
    box.append(dl);
  }
}

const peso = (n) => 'PHP ' + Number(n || 0).toLocaleString('en-PH');
const fmtTime = (iso) => new Date(iso).toLocaleString('en-PH', { dateStyle: 'medium', timeStyle: 'short' });
const typeName = (t) => (t === 'car' ? 'Car' : 'Motorcycle');

function fmtMinutes(mins) {
  mins = Math.round(mins);
  const h = Math.floor(mins / 60);
  return h ? h + ' h ' + (mins % 60) + ' min' : mins + ' min';
}

// Build table safely
function makeTable(headers, rows, emptyText) {
  if (!rows.length) return el('p', 'empty', emptyText || 'No data yet.');
  const table = el('table');
  const thead = el('thead');
  const hr = el('tr');
  headers.forEach((h) => hr.append(el('th', '', h)));
  thead.append(hr);
  const tbody = el('tbody');
  rows.forEach((r) => {
    const tr = el('tr');
    r.forEach((cell) => tr.append(el('td', '', String(cell))));
    tbody.append(tr);
  });
  table.append(thead, tbody);
  const wrap = el('div', 'table-wrap');
  wrap.append(table);
  return wrap;
}
