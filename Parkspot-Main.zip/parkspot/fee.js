// fee.js - fee calculation
// rate: prices, cfg: settings

function computeFee(entryTime, exitTime, rate, cfg, isLost) {
  // Lost ticket penalty
  if (isLost) return cfg.lostFee;

  const minutes = (new Date(exitTime) - new Date(entryTime)) / 60000;

  // Free grace period
  if (minutes <= cfg.graceMinutes) return 0;

  // Full days, then hourly
  const days = Math.floor(minutes / 1440);
  const rest = minutes - days * 1440;
  const restFee = rest > 0 ? Math.min(Math.ceil(rest / 60) * rate.per_hour, rate.daily_max) : 0;
  return days * rate.daily_max + restFee;
}

module.exports = { computeFee };